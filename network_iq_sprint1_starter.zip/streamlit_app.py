import os
import pandas as pd
import pyarrow.parquet as pq
import streamlit as st

st.title("Network IQ — EDA (MVP Stub)")

parquet_dir = "data/curated/parquet"
if not os.path.exists(parquet_dir):
    st.info("Run the ingest step first to generate Parquet files.")
else:
    # Read a small sample for demo
    files = [os.path.join(parquet_dir, f) for f in os.listdir(parquet_dir) if f.endswith(".parquet")]
    if not files:
        st.info("No Parquet files found. After running ingest, reload this app.")
    else:
        # Collect a few files into a dataframe
        dfs = []
        for root, _, fs in os.walk(parquet_dir):
            for f in fs:
                if f.endswith(".parquet"):
                    dfs.append(pd.read_parquet(os.path.join(root,f)))
                    if len(dfs) >= 5:
                        break
            if len(dfs) >= 5:
                break
        if dfs:
            df = pd.concat(dfs, ignore_index=True)
            st.write("Rows:", len(df))
            st.dataframe(df.head(50))
            # Simple by-hour view
            if "hour" in df.columns and "throughput_mbps" in df.columns:
                hourly = df.groupby("hour")["throughput_mbps"].mean().reset_index()
                st.line_chart(hourly, x="hour", y="throughput_mbps")